package com.example.calculadorademo

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    lateinit var inputText: TextView
    var operatorsArray = arrayOf("+", "-", "X", "/", "%")
    var inputValue1: String? = null
    var inputValue2: String? = null
    var operador: String? = null
    var isOperatorSelected = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inputText = findViewById(R.id.inputText)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    fun cleanData(view: View) {
        inputValue1 = null
        inputValue2 = null
        operador = null
        isOperatorSelected = false
        inputText.text = ""
    }

    fun getResult(view: View) {
        if (inputValue1 != null && operador != null && inputValue2 != null) {
            val num1 = inputValue1?.toDoubleOrNull() ?: 0.0
            val num2 = inputValue2?.toDoubleOrNull() ?: 0.0

            val result = when (operador) {
                "+" -> num1 + num2
                "-" -> num1 - num2
                "X" -> num1 * num2
                "/" -> if (num2 != 0.0) num1 / num2 else {
                    //inputText.text = "INDETERMINADO"
                    Thread.sleep(2000)
                    cleanData(view)
                    return
                }
                "%" -> num1 % num2
                else -> 0.0
            }

            inputText.text = result.toString()
            inputValue1 = result.toString()
            inputValue2 = null
            operador = null
            isOperatorSelected = false
        } else {
            //inputText.text = "SIN OPERACIÓN"
            Thread.sleep(2000)
            cleanData(view)
        }
    }

    fun getInputData(view: View) {
        val button = view as Button
        val buttonText = button.text.toString()

        if (buttonText in operatorsArray) {
            if (inputValue1 != null && !isOperatorSelected) {
                operador = buttonText
                isOperatorSelected = true
                inputText.text = "${inputValue1 ?: ""} $operador"
            } else if (isOperatorSelected) {
                getResult(view)
                operador = buttonText
                isOperatorSelected = true
                inputText.text = "${inputValue1 ?: ""} $operador"
            }
        } else {
            if (buttonText == ".") {
                if ((!isOperatorSelected && inputValue1?.contains(".") == true) ||
                    (isOperatorSelected && inputValue2?.contains(".") == true)) {
                    return
                }
            }

            if (!isOperatorSelected) {
                inputValue1 = (inputValue1 ?: "") + buttonText
            } else {
                inputValue2 = (inputValue2 ?: "") + buttonText
            }
            inputText.text = "${inputValue1 ?: ""} ${operador ?: ""} ${inputValue2 ?: ""}".trim()
        }
    }



    fun deleteLastInput(view: View) {
        val currentText = inputText.text.toString()

        if (currentText.isNotEmpty()) {
            if (!isOperatorSelected) {
                inputValue1 = inputValue1?.dropLast(1)
                inputText.text = inputValue1 ?: ""
            } else if (isOperatorSelected && inputValue2.isNullOrEmpty()) {
                operador = null
                isOperatorSelected = false
                inputText.text = inputValue1 ?: ""
            } else {
                inputValue2 = inputValue2?.dropLast(1)
                inputText.text = "${inputValue1 ?: ""} ${operador ?: ""} ${inputValue2 ?: ""}".trim()
            }
        }
    }
}
